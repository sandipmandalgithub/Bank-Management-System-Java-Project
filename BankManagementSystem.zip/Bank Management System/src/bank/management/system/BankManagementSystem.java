
package bank.management.system;


public class BankManagementSystem {

        public static void main(String[] args) {
        
}
    
}
